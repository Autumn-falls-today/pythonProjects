import turtle 
import cells
import time
import drawing
import behavior
from copy import deepcopy

"""===================================================================="""
WINDOW  = None
# X and Y dimensions of the window; measured in pixels
WINX, WINY = 500, 500

def main():
    """Main function"""
    # Do not edit
    def setupWin():
        global WINDOW
        # making turtle object
        WINDOW = turtle.Screen()
        # setup the screen size
        WINDOW.setup(WINX,WINY)
        # set the background color
        WINDOW.bgcolor("white")

    
    setupWin()


    """===================================================================="""

    dingo = turtle.Turtle()
    cells.turtleQOL(dingo)
    mouseTurt = turtle.Turtle()
    cells.turtleQOL(mouseTurt)
    #need to detect where the mouse goes^
    
    # Turn off automatic screen updates
    WINDOW.tracer(0)
    
    """===================================================================="""

    #setup
    test = cells.Grid(3,3,135)
    test.makeGrid()
    weightedOdds = []
    for i in range(20):
        for k in [["forward",0],["left",0],["right",0],["backward",0],["circle",0,0]]:
            weightedOdds.append(deepcopy(cells.Trait(k)))
            #sets up weightedOdds list
    NGButton = cells.Cell(-40,-225,50,20)
    RSButton = cells.Cell(40,-225,50,20)
    

    for cell in test.cells:
        #happens on newgen:
        behavior.newGen(cell,[],weightedOdds)
    
    
    def hover(event):
        mouse_x = event.x - WINX / 2
        mouse_y = WINY / 2 - event.y
        mouseTurt.goto(mouse_x,mouse_y)
        test.checkOver("hover",mouseTurt,test.commands)
        test.checkOver("hover",mouseTurt,test.cells)
    def click(event):
        mouse_x = event.x - WINX / 2
        mouse_y = WINY / 2 - event.y
        mouseTurt.goto(mouse_x,mouse_y)
        test.checkOver("click",mouseTurt,test.commands)
        test.checkOver("click",mouseTurt,test.cells)

    #constantly detecting/running:
    WINDOW.getcanvas().bind("<Motion>", hover)
    WINDOW.getcanvas().bind("<Button-1>", click)
    
    def TICK():
        for cell in test.commands:
            cell.makeOutline(test.commands)
            drawing.drawTraits(cell)
        if test.commands[0].selected:
            test.commands[0].selected = False
            tempList = []
            for cell in test.cells:
                if cell.selected:
                    tempList.append(cell)
                    cell.selected = False
            test.parents = tempList
            #effect weightedOdds?
            print(weightedOdds)
            behavior.calculateWeight(test.parents,weightedOdds)
            print(weightedOdds)
            for cell in test.cells:
                behavior.newGen(cell,test.parents,weightedOdds)
        if test.commands[1].selected:
            test.commands[1].selected = False
            for cell in test.cells:
                behavior.newGen(cell,test.parents,weightedOdds)
        for cell in test.cells:
            cell.makeOutline(test.cells)
            drawing.drawTraits(cell)
            #for trait in cell.traitList:
                #print(trait.command,trait.magnitude)
        dingo.goto(-40,-230)
        dingo.write("Next Gen", align="center", font=("Arial", 6, "normal"))
        dingo.goto(40,-230)
        dingo.write("Reset Gen", align="center", font=("Arial", 6, "normal"))
        
        WINDOW.update()
        turtle.ontimer(TICK,200)

    TICK()
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    """===================================================================="""
    
    WINDOW.mainloop()

main()