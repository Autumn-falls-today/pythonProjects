import turtle

#see notes on other assignments about turtleQOL
def turtleQOL(turtle):
    turtle.speed(0)
    turtle.ht()
    turtle.penup()


#this just makes the grid
class Grid:
    def __init__(self,rows,columns,size):
        self.rows = rows
        self.columns = columns
        self.size = size
        #going to be a list of the cells
        self.cells = []
        NGButton = Cell(-40,-225,50,20)
        RSButton = Cell(40,-225,50,20)
        self.commands = [NGButton,RSButton]
        self.parents = []
    def makeGrid(self):
        #centering around 0,0
        self._startingCell = [-1 * self.size * (self.columns / 2 - 0.5), self.size * (self.rows / 2 - 0.5)]
        #starting to make the rows
        for row in range(self.rows):
            #for each cell in a row, draw it then move forward
            for sq in range(self.columns):
                makeCell = Cell(self._startingCell[0],self._startingCell[1],self.size)
                self.cells.append(makeCell)
                self._startingCell[0] += self.size
            #now we're moving back and going down one
            self._startingCell[0] = -1 * self.size * (self.columns / 2 - 0.5)
            self._startingCell[1] -= self.size
    def checkOver(self,mouseArg,turtle,cellsOrCmds):
        #whenever mouse moves for each cell check if turtle that follows mouse
        #is in there, and if so turn cell.hoverOver true.
        for cell in cellsOrCmds:
            if cell.insideBox(turtle) == False:
                if mouseArg == "hover":
                    cell.hoverOver = False
            if cell.insideBox(turtle):
                cell.hoverOver = True
                if mouseArg == "click":
                    cell.selected = not cell.selected
#decided that the making of a cell shouldn't be in the grid class, though
#the grid class calls the function and records it all.
class Cell:
    def __init__(self,xCor,yCor,leng,ht=0):
        self.xCor = xCor
        self.yCor = yCor
        self.leng = leng
        #if height isn't specified it defaults to length, otherwise it is what it is
        if ht == 0:
            self.ht = leng
        else:
            self.ht = ht
        self.traitList=[]
        self.age = 6
        self.copies = 6
        #this just sets the inital age and copies, will be changed later 
        self.hoverOver = False
        self.selected = False
        #these two can be changed and affect the box        
        self.outline = turtle.Turtle()
        self.turtle = turtle.Turtle()
        turtleQOL(self.outline)
        turtleQOL(self.turtle)
        #one turtle for the outline, one for the actual shapes.
        self.degrees = 0
    def makeOutline(self,gridInstCells=[]):
        #i want to not make the code name-dependant (i.e. test.cells), and so i 
        #need to pass the grid the cell is in to fix stuff in self.hoverOver
        self.outline.goto(self.xCor-self.leng/2,self.yCor-self.ht/2)
        #bigger pensize means easier to clean/cover up boundary interactions
        self.outline.pensize(3)
        #now we worry about hoverOver and selected
        self.outline.fillcolor("White")
        if self.selected:
            self.outline.fillcolor("#ccfccc")
            self.outline.begin_fill()        
        if self.hoverOver:
            #had a weird problem where cell's wouldn't ungrey, fixing that here
            for cell in gridInstCells:
                if cell.outline.fillcolor() == "#eeeeff":
                    cell.outline.fillcolor("White")
            if self.outline.fillcolor() == "White": 
                self.outline.fillcolor("#eeeeff")
            
        self.outline.begin_fill()
        self.outline.pendown()
        for i in range(2):
            self.outline.forward(self.leng)
            self.outline.left(90)
            self.outline.forward(self.ht)
            self.outline.left(90)
        self.outline.end_fill()
        self.outline.penup()
        self.outline.goto(self.xCor,self.yCor)
        
    def insideBox(self,turtle):
        return((self.xCor - self.leng/2 < turtle.xcor() <
        self.xCor + self.leng/2) and 
        (self.yCor - self.ht/2 < turtle.ycor() < 
        self.yCor + self.ht/2))
    
class Trait:
    #making a trait class for easier storing
    def __init__(self,chromo,cirRad=0):
        self.command = chromo[0]
        self.magnitude = chromo[1]
        self.cirRad = cirRad