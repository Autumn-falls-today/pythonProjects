import math

class Registry:
    self.register = []
    self.G = 1
    
    def addToRegister(target):
        self.register.append(target)
    
class Object(Registry):
    #can set the starting coords,size,mass,starting velocity,and whether it's moveable or not
    def __init__(self,coords,radius,mass=(math.pi*size)**2,velocity=[0,0],movable = True):
        Registry.addToRegister(self)
        self.coords = coords
        self.radius = radius
        self.mass = mass
        self.velocity = velocity
        self.movable = movable
    
    #figure out how much gravity an object exerts on another
    def exertGravity(self,target):
        #calculate force
        force = Registry.G * self.mass * target.mass / self.findDistanceBetweenCenters(target) ** 2
        #figure out angle, to calculate force into x and y velocities
        angle = math.atan2(target.centY-self.centY,target.centX-self.centX)
        target.velocity[0] += math.cos(angle) * force
        target.velocity[1] += math.sin(angle) * force
    
    #because we use this with both temp and actual centers, set up an arguement to determine
    def findDistanceBetweenCenters(self,otherShape,temp=False):
        if temp:
            return(math.hypot((self.tempX-otherShape.tempX),(self.tempY-otherShape.tempY)))
        else:
            return(math.hypot((self.centX-otherShape.centX),(self.centY-otherShape.centY)))

    
    #first each shape will attempt to move, then it will check if it is intercepting with any
    def startMove(self):
        self.tempX = self.coords[0]+self.velocity[0]
        self.tempY = self.coords[1]+self.velocity[1]
    
    #check if any shapes are intercepting, if so check when exactly to have a frame then
    #push away with a force based on velocity & mass
    def checkInterceping(self):
        for shape in Registry.register:
            if shape != self:
                #if shapes are intersecting after movement, push away from each other (mass based)
                if self.radius+shape.radius>self.findDistanceBetweenCenters(shape,True):
                    totalMass = self.mass + shape.mass
                    time = 
    
#function to affect everything with gravity
def doGravity():
    for shape in Registry.register:
        for otherShape != shape:
            otherShape.exertGravity(shape)