import turtle
import Object

"""=========================================================================="""
WINDOW  = None
# X and Y dimensions of the window; measured in pixels
WINX, WINY = 450, 450

def main():
    """Main function"""
    # Do not edit
    def setupWin():
        global WINDOW
        # making turtle object
        WINDOW = turtle.Screen()
        # setup the screen size
        WINDOW.setup(WINX,WINY)
        # set the background color
        WINDOW.bgcolor("white")

    setupWin()
    WINDOW.tracer(0)
    """=================================================================="""
    
    
    
    
    
    
    
    
    """=================================================================="""
    
    WINDOW.mainloop()

main()