#what "traits" can we have? forward,left,right,backward,circle, is that good?

#three behaviors we can do from a list of commands to make new generations: 

#1. take those commands and make it more likely that any new commands are of 
#those type (we won't factor in the magnitude, that can stay "perfectly" random)

#2. for each command index number, we give a large chance that the new gen's
#command at that index is one of the chosen parents's command at said index,
#but then also a small chance it's something random (unweighted random)

#3. straight up just take the first part of command list and fuse it to the
#second part of another list.

import random
from cells import Trait
from copy import deepcopy
#learned i need to use use this after a lot of trouble

#broader function that takes the selected parents('s traits) and gives an outcome
class newGen:
    
    def __init__(self,target,parentList,weightedOdds):
        self.weightedOdds = weightedOdds
        self.target = target
        self.parentList = parentList
        self.newTraits = []
        #its easier to make a list of newTraits here, then switch the cells traits to this later
        if len(parentList) > 0:
            self.varyAgeCop("copy",random.choice(self.parentList))
            self.varyAgeCop("age",random.choice(self.parentList))
        #i know that age will be overriden in the splice behavior, thats on purpose
        
        #3 different behavior functions, not privated in case someone would want to call specific behaviors
        b = random.randint(0,2)
        if b == 0 and len(self.parentList) > 0:
            #no reason to inherit if there's no parents
            self.inheritedGen()
        elif b == 1 and len(self.parentList) > 1:
            #no reason to splice if there's only one parent
            self.splicedGen()
        else:
            self.weightedGen()
        
        #after whatever process, finally change the targets traits to new ones
        target.traitList =(self.newTraits)
    
    
    def varyAgeCop(self,i,p):
        #remembered you wanted amount of copies and age to change, so here's that based off of parents
        if i == "copy":
            temp = p.copies
        if i == "age":
            temp = p.age
        temp += random.randint(-2,2)
        if temp <= 2:
            temp = 3
            #set a lower bound, may as well set an upper bound so things don't get super crazy
        if temp >= 11:
            temp = 10
        #idk if this exactly counts as polymorphism but i used the same code for age and copies
        #and then i just assigned them.
        if i == "copy":
            self.target.copies = temp
        if i == "age":
            self.target.age = temp
    def weightedGen(self):
        # for however "old" it is, we add on to a list a random trait from the
        #weighted list.
        for _ in range(self.target.age):
            self.newTraits.append((self.weightedOdds[random.randint(0,99)]))
            
    def inheritedGen(self):
        randomTrait = [["forward",0],["left",0],["right",0],["backward",0],["circle",0]]
        #for each trait, give it a large chance it randomly takes it from a
        #parent's trait from the same index, and small chance of equal random
        for trait in range(self.target.age):
            inhChance = random.randint(0,len(self.parentList))
            #i'm aware the len() is one extra than the highest index on the list, 
            #that is my small chance of randomness: i.e. more parents = smaller
            #chance of being completely random
            try:
                self.newTraits.append(deepcopy(self.parentList[inhChance].traitList[trait]))
                #checks if a random parent's trait is there, if out of range
                #(because parent age isn't old enough or if the random triggers!)
                #then it does a random trait.
            except IndexError as e:
                if "list index out of range" in str(e):
                    self.newTraits.append(deepcopy(Trait(randomTrait[random.randint(0,4)])))
                    #random trait is added if what we want is out of range
            else:
                self.newTraits.append(deepcopy(self.parentList[inhChance].traitList[trait]))

    def splicedGen(self):
        parent1 = random.choice(self.parentList)
        parent2 = random.choice(self.parentList)
        twoParents = [parent1,parent2]
        slice = random.randint(1,min(len(parent1.traitList),len(parent2.traitList)))
        #now that we have the place to slice, we need to slice and catalogue
        catalogue = []
        for parent in twoParents:
            catalogue.append([parent.traitList[:slice],parent.traitList[slice:]])
            #stores each parent's slices as the value of a num in a dictionary.
        #because it's directly spliced, the magnitudes don't need to be randomized
        chosen = random.randint(0,1)
        self.newTraits = (catalogue[chosen][0] + 
        (catalogue[((chosen + 1) % 2)][1]))
        self.age = len(self.newTraits)
        #takes a random first half and adds (then mod's) a number and attach 
        #the second half, slicing together the two.

def calculateWeight(parentList,weightedOdds):
#weightedOdds is list of the current balance of traits, we input a new series of
#traits and for each input, a random trait will be pushed out of the balance,
#otherwise as more and more generations go on, they will have less value
    #for each parent
    for parent in parentList:
        #for each "trait" in the parent
        for trait in parent.traitList:
            if trait.command == "forward":
                weightedOdds.append(Trait(["forward",0]))
            elif trait.command == "left":
                weightedOdds.append(Trait(["left",0]))
            elif trait.command == "right":
                weightedOdds.append(Trait(["right",0]))
            elif trait.command == "backward":
                weightedOdds.append(Trait(["backward",0]))
            elif trait.command == "circle":
                weightedOdds.append(Trait(["circle",0]))
            del weightedOdds[random.randint(0,99)]