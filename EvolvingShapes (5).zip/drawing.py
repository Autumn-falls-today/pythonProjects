import turtle
import math
import random
import cells
import behavior


class drawTraits:
    #all important drawing stuff (except box outlines) are here!
    def __init__(self,target):
        self.target = target
        self.target.turtle.goto(self.target.xCor,self.target.yCor)
        self.target.turtle.clear()
        #in lieu of a animate function like one of my last assignments before this,
        #i just put the degrees as part of the draw function and as everything is
        #relative here, it works swell :D
        self.target.degrees += 1
        if self.target.hoverOver:
            self.target.degrees += 9
        #if hovering over speed up the moving, i really like this feature!!!
        #it would definitely look a lot better if i wasn't pushing python turtle
        #to it's absolute max heehee
        self.target.turtle.pendown()
        for trait in self.target.traitList:
            self.interpretTraits(trait)
        self.target.turtle.penup()
        #draws stuff then does the copies, all relative so "animating" is a breeze
        self.reflections()
        
        #making a seperate list of the commands so copies can follow along
        
    def interpretTraits(self,trait):
        #translate the command into turtle movements
        if trait.magnitude == 0:
            if trait.command == "forward" or trait.command == "backward":
                trait.magnitude = random.randint(1,6) * 5
                self.executeTrait(trait)
                #forward and backwards have the same magnitude limits, so the above code
                #consolidates that, and then dispenses the proper command as well.
            elif trait.command == "left" or trait.command == "right":
                trait.magnitude = random.randint(1,18) * 15
                self.executeTrait(trait)
                #left,right, and circle have the same magnitude limits, so the code
                #consolidates that, and then dispenses the proper command as well.        
            elif trait.command == "circle":
                trait.magnitude = random.randint(1,18) * 15
                trait.cirRad = random.randint(1,30)
                self.executeTrait(trait)
            
    
    def executeTrait(self,trait):
        #if its something that moves, it moves, if it's left or right it just does that
        if trait.command == "forward" or "backward" or "circle":
            self.move(trait)
            return
        elif trait[0] == "left":
            self.target.turtle.left(trait.magnitude)
            return
        elif trait[0] == "right":
            self.target.turtle.right(trait.magnitude)
            return
    
    #making a class that incrementally moves the commands, to check if it is
    #out of bounds.
    def move(self,trait):
        counter = 0
        #because circle uses a slightly different call, it needs its own thing
        if trait.command == "circle":
            while trait.magnitude > counter:
                if self.target.insideBox(self.target.turtle):
                    self.target.turtle.pendown()
                else:
                    self.target.turtle.penup()
                self.target.turtle.circle(trait.cirRad,1)
                counter += 1
        #in essence, this method just takes inputs and in very small steps moves
        #them forward, and if they get out of bounds then the turtles continue,
        #to keep the drawing from being all messed up, but while OOB has the penup
        else:
            while trait.magnitude > counter:
                if self.target.insideBox(self.target.turtle):
                    self.target.turtle.pendown()
                else:
                    self.target.turtle.penup()
                if trait.command == "forward":
                    self.target.turtle.forward(1)
                else:
                    self.target.turtle.backward(1)
                counter += 1
                
    
    
    def reflections(self):
    #because it is written out confusingly, i made it it's own function for ease of viewing
    #all this does is equally space out copies of whatever the drawing is
        for copy in range(self.target.copies):
            self.target.turtle.goto(self.target.xCor,self.target.yCor)
            self.target.turtle.setheading(0)
            self.target.turtle.right(self.target.degrees)
            self.target.turtle.left(360/self.target.copies * copy)
            self.target.turtle.pendown()
            
            for trait in self.target.traitList:
                self.executeTrait(trait)
            self.target.turtle.penup()