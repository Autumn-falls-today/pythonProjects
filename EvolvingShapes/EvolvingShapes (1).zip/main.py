import turtle 
import cells
import time
import drawing
import behavior

"""===================================================================="""
WINDOW  = None
# X and Y dimensions of the window; measured in pixels
WINX, WINY = 500, 500

def main():
    """Main function"""
    # Do not edit
    def setupWin():
        global WINDOW
        # making turtle object
        WINDOW = turtle.Screen()
        # setup the screen size
        WINDOW.setup(WINX,WINY)
        # set the background color
        WINDOW.bgcolor("white")

    
    setupWin()
    """===================================================================="""

    # Turn off automatic screen updates
    WINDOW.tracer(0)
    
    """===================================================================="""
    
    test = cells.Grid(3,3,135)
    test.makeGrid()
    
    for cell in test.cells:
        behavior.newGen(cell,[])
        drawing.drawTraits(cell)
    

    """===================================================================="""
    
    WINDOW.mainloop()

main()