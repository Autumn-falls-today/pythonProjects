import turtle
import math
import random

class drawTraits:
    def __init__(self,target):
        self.target = target
        self.target.turtle.goto(self.target.xCor,self.target.yCor)
        self.target.turtle.pendown()
        for trait in self.target.traitList:
            self.interpretTraits(trait)
        self.target.turtle.penup()
        self.reflections()
        
        #making a seperate list of the commands so copies can follow along
        
    def interpretTraits(self,trait):
        #translate the command into turtle movements
        if trait[0] == "forward" or "backward":
            trait[1] = random.randint(1,9) * 5
        if trait[0] == "forward":
            self.move(trait)
            return
        elif trait[0] == "backward":
            self.move(trait)
            return
        #forward and backwards have the same magnitude limits, so the above code
        #consolidates that, and then dispenses the proper command as well.
        
        if trait[0] == "left" or "right" or "circle":
            trait[1] = random.randint(1,18) * 15
        if trait[0] == "left":
            self.target.turtle.left(trait[1])
            return
        elif trait[0] == "right":
            self.target.turtle.right(trait[1])
            return
        elif trait[0] == "circle":
            #left,right, and circle have the same magnitude limits, so the code
            #consolidates that, and then dispenses the proper command as well.
            trait.append(random.randint(1,30))
            self.move(trait)
            return
    
    #quick class that's similar to above (consolidating causes issues??)
    def executeTrait(self,trait):
        if trait[0] == "forward":
            self.move(trait)
            return
        elif trait[0] == "backward":
            self.move(trait)
            return
        if trait[0] == "left":
            self.target.turtle.left(trait[1])
            return
        elif trait[0] == "right":
            self.target.turtle.right(trait[1])
            return
        elif trait[0] == "circle":
            self.move(trait)
            return
    
    
    #making a class that incrementally moves the commands, to check if it is
    #out of bounds.
    def move(self,trait):
        counter = 0
        #because circle uses a slightly different call, it needs its own thing
        if trait[0] == "circle":
            while trait[1] > counter:
                if self.insideBox(self.target.turtle):
                    self.target.turtle.pendown()
                else:
                    self.target.turtle.penup()
                self.target.turtle.circle(trait[2],1)
                counter += 1
        else:
            while trait[1] > counter:
                if self.insideBox(self.target.turtle):
                    self.target.turtle.pendown()
                else:
                    self.target.turtle.penup()
                if trait[0] == "forward":
                    self.target.turtle.forward(1)
                else:
                    self.target.turtle.backward(1)
                counter += 1
    
    #because it is written out confusingly, i made it it's own function for ease of viewing
    def insideBox(self,turtle):
        return(self.target.xCor - self.target.size/2 < turtle.xcor() <
        self.target.xCor + self.target.size/2 and 
        self.target.yCor - self.target.size/2 < turtle.ycor() < 
        self.target.yCor + self.target.size/2)
    
    def reflections(self):
        for copy in range(self.target.copies):
            self.target.turtle.goto(self.target.xCor,self.target.yCor)
            self.target.turtle.setheading(0)
            self.target.turtle.left(360/self.target.copies * copy)
            self.target.turtle.pendown()
            
            for trait in self.target.traitList:
                self.executeTrait(trait)
            self.target.turtle.penup()

#copied this class from a previous project

    """def animate(self):
        self.target.turtle.clear()
        self.degrees += 1
        self.target.turtle.right(self.degrees)
        self.circleShape()
        self.target.turtle.setheading(0)
        self.target.draw()"""