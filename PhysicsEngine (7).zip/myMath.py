import math


class doMath:
    def __init__(self,targetVertex,vertexShape,targetLine,lineShape):
        #define vertex constants
        self.vertexShape = vertexShape
        self.lineShape = lineShape
        self.targetVertex = targetVertex
        self.targetLine = targetLine
        
        self.findT()

    #New idea of what i want to do: check what is the smallest time that it crosses the line
    #then check if there is a smaller residual between right before it hits the line
    #or right after. take the smaller one and get the time from that.
    
    def __repr__(self):
        return(self.smallestTime)

    def findT(self):
        
        #make a list to keep track of the times
        timeList = []
        
        i = 1
        #get a lot of small times,and check if they cross the line or not
        while i < 16:
            if iscolliding([[self.vertexShape.centX+self.vertexShape.horVelocity*t,
            self.vertexShape.centY+self.vertexShape.vertVelocity*t],
            #above lines input where the vertexShapes' CoM would be
            #below inputs where the target/lines vertices would be
            [xWhenT(self.targetVertex),yWhenT(self.targetVertex)]],
            
            [[xWhenT(self.targetLine[0]),yWhenT(self.targetLine[0])],
            [xWhenT(self.targetLine[1]),yWhenT(self.targetLine[1])]]):
                timeList.append([i/16,True])
            else:
                timeList.append([i/16,False])
            i += 1
        
        #now we check what the smallest time when a collision happens is.
        
        #if the first time collides, we pick it automatically (also prevents syntax error)
        for i in range(16):
            if timeList[i][1]:
                self.smallestTime = (timeList[i][0])
                break
            if i == 15 and timeList[i+1][1] == False:
                self.smallestTime = None
        
        
    
#use these functions to find where a point is at a given time
def xWhenT(targetShape, targetVertex, t):
    return(targetVertex[0]*math.cos(targetVertex[1] + t*targetShape.spin) + 
    targetShape.horVelocity*t + targetShape.centX)
    #x coordinate depending on time
    
def yWhenT(targetShape, targetVertex, t):
    return(targetVertex[0]*math.sin(targetVertex[1] + t*targetShape.spin) + 
    targetShape.vertVelocity*t + targetShape.centY) 
    #y coordinate depending on time
    

def polarToCartesian(coordSet,targetShape):
        #takes a polar coordinate and makes it cartesian
            x = targetShape.centX + (math.cos(coordSet[0]) * coordSet[1])
            y = targetShape.centY + (math.sin(coordSet[0]) * coordSet[1])
            return[x,y]



def isColliding(aLine,bLine):
    #this finds out if two lines intersect
    A1 = aLine[0]
    A2 = aLine[1]
    B1 = bLine[0]
    B2 = bLine[1]
    
    #getting the mx + b formulas for the lines. 
    #if x cords are on the same line we just make it super big rise/run
    
    try:
        slopeA = (A2[1]-A1[1])/(A2[0]-A1[0])
    except ZeroDivisionError:
        slopeA = 500
    else:
        slopeA = (A2[1]-A1[1])/(A2[0]-A1[0])
    finally:
        #b = y - mx
        c = A1[1] - slopeA * A1[0]
    
    try:
        slopeB = (B2[1]-B1[1])/(B2[0]-B1[0])
    except ZeroDivisionError:
        slopeB = 501
    else:
        slopeB = (B2[1]-B1[1])/(B2[0]-B1[0])
    finally:
        #b = y - mx
        d = B1[1] - slopeA * B1[0]
    
    #now we check where the intercepting point of those two lines would be
    try:
        solution = (d - c)/(slopeA - slopeB)
    except ZeroDivisionError:
        #if the slopes are parallel, we check if one of the points is on the line
        return(((min(A1[0],A2[0]) <= B1[0] <= max(A1[0],A2[0])) or (min(A1[0],A2[0]) <= B2[0] <= max(A1[0],A2[0])))
        and A1[1] == B1[1])
    else:
        solution = (d - c)/(slopeA - slopeB)
    
    #check if that point is on BOTH lines. If it's on both we say it is intersecting.
    if (min(A1[0],A2[0]) <= (slopeA * solution + c) <= (max(A1[1],A2[1]))) and (
    min(B1[0],B2[0]) <= (slopeB * solution + d) <= (max(B1[1],B2[1]))):
        return True
    else:
        return False
        
#gets the list of lines using the current CoM and polar coordinates
def getLines(target):
    tempLineList = []
    for i in range(len(target.polarVertexList)):
        tempLineList.append([polarToCartesian(target.polarVertexList[i-1],target), 
        polarToCartesian(target.polarVertexList[i],target)])
    return tempLineList