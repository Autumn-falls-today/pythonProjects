import turtle
import math
import myMath

def turtleQOL(turt):
    turt.ht()
    turt.speed(0)
    turt.penup()

class Registry:
    #used to keep track of all shapes, also wooooo class variable, very cool right
    registry = []

class Shape(Registry):
    def __init__(self,cartesianVertexList, vertVelocity = 0, horVelocity = 0, moveable = False):
        
        #here we get x and y of the center
        self.centX, self.centY = averagePoints(cartesianVertexList)
        
        
        #relative vertex list tells you how to make a shape -- contains
        #angle/distance pairs
        self.polarVertexList = []
        for cCoords in cartesianVertexList:
            self.polarVertexList.append([math.atan2(cCoords[1] - self.centY, cCoords[0] - self.centX),
            ((cCoords[0] - self.centX) ** 2 + (cCoords[1] - self.centY) ** 2) ** .5])
        
        #add on to register
        Registry.registry.append(self)
        
        
        #vertical and horizontal velocities, obv
        self.vertVelocity = vertVelocity
        self.horVelocity = horVelocity
        
        #checks if it is a movable or "environmental" shape
        self.movable = moveable
        
        #putting this here to attach gravity decorators later
        self.horizontalGrav = 0
        self.verticalGrav = 0
        
        #spin is in units of radians per frame that the angle changes/turns
        self.spin = 0
        
        #use this later to tell if shapes are close or not
        self.greatestDis = 0
        for polarPoint in self.polarVertexList:
            if polarPoint[1] > self.greatestDis:
                self.greatestDis = polarPoint[1]
        
        
        #making a turtle for drawing later
        self.turtle = turtle.Turtle()
        turtleQOL(self.turtle)
        
        #list of lines, it's a surprise tool that will help us later
        self.lineList = myMath.getLines(self)
        
        
        #needed to calculate force bc F = ma :D actually forget this i don't actually,
        #however i'll keep this stuff here and commented for posterity
        #self.area = shoelace(self.lineList)
    
    

    
    def checkOverlapping(self,closeShape):
        
        #checks each line of our shape against each line of target shape
        for i in range(len(self.lineList)):
            #for each vertex in the shape close to it
            for k in range(len(closeShape.lineList)):
                
                if isColliding(self.lineList[i],closeShape.lineList[k]):
                    return True 
                else:
                    continue
        return False
    
    def move(self):
        
        #here we calculate where the CoM would be (using a temp CoM and temp
        #angles until finalized). first we need to affect gravity onto the shape
        #and then move the temp CoM where its velocity (+new gravity) takes it
        #and if no lines cross with any other lines, it is finalized. if there
        #is a collision, we then calculate all the angles and stuff
        
        self.tempHorVel = self.horVelocity + self.horizontalGrav
        self.tempVertVelocity = self.vertVelocity + self.verticalGrav
        
        self.tempCentX = self.centX + self.tempHorVel
        self.tempCentY = self.centY + self.tempVertVelocity
        
        #checks what shapes are around it, uses the farthest magnitude to determine
        #how big the radius around it to check
        for otherShape in Registry.registry:
            if otherShape != self:
                if calcHypoDistance([self.tempCentX,self.tempCentY],
                [otherShape.centX,otherShape.centY]) <= self.greatestDis + otherShape.greatestDis:
                    #ok so above we check if the distance between the two CoM's is
                    #larger than both their furthest distance added together, and now
                    #below we check if overlapping
                    if not self.checkOverlapping(shape):
                        self.centX = self.tempCentX
                        self.centY = self.tempCentY
                        #now we check if any overlapping lines, if so then find the collision pos
                        #vertexAndT = self.getCollisionPosition(shape)
        self.lineList = myMath.getLines(self)
        self.draw()
        
        
    def getCollisionPosition(self, closeShape):
        #checks which vertex collides first (smallest time) and at what time and then returns 
        #the vertices at that time as well at the ID of the collision vertex
        vertex = -1
        t = 1
        for i in range(len(self.polarVertexList)):
            for line in closeShape.lineList:
                t1 = myMath.doMath(self.polarVertexList[i], self, line, closeShape)
                if int(repr(t1)) == 0:
                    continue
                if int(repr(t1)) < t:
                    t = int(repr(t1))
                    vertex = i
                    #make edge case for when two t are equal
        return [vertex,t]
    
    def applyCollisionForces(self):
        #actually moves forces
        pass
    
    def draw(self):
        #send turtle to first point of first line in lineList
        self.lineList = myMath.getLines(self)
        print(self.polarVertexList)
        self.turtle.goto(self.lineList[0][0])
        self.turtle.pendown()
        #we learned last time end_fill updates the screen auto, so not doing that
        #until i get a fix
        #if self.moveable:
            #self.turtle.begin_fill()
        for i in range(len(self.lineList)):
            self.turtle.goto(self.lineList[i][1])
        #if self.moveable:
            #self.turtle.end_fill()
        self.turtle.penup()
        
        
    

    

def averagePoints(cVertexList):
    #this averages the points x and y coords and returns it, wanted to clean up
    #the init function as best as i could.
    xVal = 0
    yVal = 0
    for vertex in cVertexList:
        xVal += vertex[0]
        yVal += vertex[1]
    print(xVal/len(cVertexList),yVal/len(cVertexList))
    return[xVal/len(cVertexList),yVal/len(cVertexList)]

################################################################################



#use to find distance between two points, used in move()
def calcHypoDistance(point1, point2):

    x1, y1 = point1
    x2, y2 = point2
    
    distance = math.hypot(x2 - x1, y2 - y1)
    return distance




#def shoelace(lineList):
#    #determines the area by a math formula i don't completely get, but i get the code!
#    
#    area = 0.0
#    for i in range(len(lineList)):
#        x1, y1 = lineList[i - 1][0]
#        x2, y2 = lineList[i][1]
#        area += (x1 * y2) - (x2 * y1)
#
#    return abs(area / 2.0)