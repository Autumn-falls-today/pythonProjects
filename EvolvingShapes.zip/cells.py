import turtle
#see notes on other assignments about turtleQOL
def turtleQOL(turtle):
    turtle.speed(0)
    turtle.ht()
    turtle.penup()

class Grid:
    def __init__(self,rows,columns,size):
        self.rows = rows
        self.columns = columns
        self.size = size
        #going to be a list of the cells
        self.cells = []
    def makeGrid(self):
        #centering around 0,0
        self._startingCell = [-1 * self.size * (self.columns / 2 - 0.5), self.size * (self.rows / 2 - 0.5)]
        #starting to make the rows
        for row in range(self.rows):
            #for each cell in a row, draw it then move forward
            for sq in range(self.columns):
                makeCell = Cell(self._startingCell[0],self._startingCell[1],self.size)
                self.cells.append(makeCell)
                self._startingCell[0] += self.size
            #now we're moving back and going down one
            self._startingCell[0] = -1 * self.size * (self.columns / 2 - 0.5)
            self._startingCell[1] -= self.size

#decided that the making of a cell shouldn't be in the grid class, though
#the grid class calls the function and records it all.
class Cell:
    def __init__(self,xCor,yCor,leng,ht=0):
        self.xCor = xCor
        self.yCor = yCor
        self.leng = leng
        if ht == 0:
            self.ht = leng
        else:
            self.ht = ht
        self.outline = turtle.Turtle()
        self.turtle = turtle.Turtle()
        turtleQOL(self.outline)
        turtleQOL(self.turtle)
        #one turtle for the outline, one for the actual shapes. also the trait list
        self.traitList=[]
        self.makeOutline()
        self.age = 8
        self.copies = 3
    def makeOutline(self):
        self.outline.goto(self.xCor-self.leng/2,self.yCor-self.ht/2)
        #bigger pensize means easier to clean/cover up boundary interactions
        self.outline.pensize(3)
        self.outline.pendown()
        for i in range(2):
            self.outline.forward(self.leng)
            self.outline.left(90)
            self.outline.forward(self.ht)
            self.outline.left(90)
        self.outline.penup()
        self.outline.goto(self.xCor,self.yCor)
        
    def insideBox(self,turtle):
        return(self.xCor - self.leng/2 < turtle.xcor() <
        self.xCor + self.leng/2 and 
        self.yCor - self.ht/2 < turtle.ycor() < 
        self.yCor + self.ht/2)
        
class Trait:
    #making a trait class for easier storing
    def __init__(self,chromo,cirRad=0):
        self.command = chromo[0]
        self.magnitude = chromo[1]
        self.cirRad = cirRad