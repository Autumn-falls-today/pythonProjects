#what "traits" can we have? forward,left,right,backward,circle, is that good?

#three behaviors we can do from a list of commands to make new generations: 

#1. take those commands and make it more likely that any new commands are of 
#those type (we won't factor in the magnitude, that can stay "perfectly" random)

#2. for each command index number, we give a large chance that the new gen's
#command at that index is one of the chosen parents's command at said index,
#but then also a small chance it's something random (unweighted random)

#3. straight up just take the first part of command list and fuse it to the
#second part of another list.

import random
import numpy as np
from cells import Trait

from copy import deepcopy
#learned i need to use use this after a lot of trouble

#broader function that takes the selected parents('s traits) and gives an outcome
class newGen:
    
    #class variable so all instances can share the list and no global var:
    weightedOdds = []
    
    def __init__(self,target,parentList):
        self.target = target
        self.parentList = parentList
        self.newTraits = []
        if len(parentList) > 0:
            self.varyAgeCop(self.target.copies,(random.choice(parentList)).copies)
            self.varyAgeCop(self.target.age,(random.choice(parentList)).age)
        #i know that age will be overriden in the splice behavior, thats on purpose
        
        #we will make different behavior functions and won't private them in
        #case someone would want to look at/call specific behaviors       
        b = 0 #random.randint(0,2)
        if b == 0:
            self.weightedGen()
        elif b == 1 and len(self.parentList) > 1:
            #no reason to splice if there's only one parent
            self.splicedGen()
        else:
            self.inheritedGen()
        
        #after whatever process, finally change the targets traits to new ones
        target.traitList =(self.newTraits)
    
    
    def varyAgeCop(self,i,p):
        #remembered you wanted amount of copies and age to change, so heres that.
        #i could go more in depth, but don't really want to
        temp = p
        p += random.randint(-2,2)
        i = p
        if i <= 0:
            i = 1
            #set a lower bound, may as well set an upper bound
        if i >= 13:
            i = 12
    def weightedGen(self):
        "newGen.weightedOdds = CalculateWeight(newGen.weightedOdds,self.parentList)"
        #put this ^ before making each gen so it only happens once a gen.
        # for however "old" it is, we add on to a list a random trait from the
        #weighted list.
        for _ in range(self.target.age):
            self.newTraits.append(deepcopy(newGen.weightedOdds[random.randint(0,99)]))
    
    def inheritedGen(self):
        randomTrait = [["forward",0],["left",0],["right",0],["backward",0],["circle",0]]
        #for each trait, give it a large chance it randomly takes it from a
        #parent's trait from the same index, and small chance of equal random
        for trait in range(self.age):
            inhChance = random.randint(0,len(self.parentList))
            #i'm aware the len() is one extra than the highest index on the list, 
            #that is my small chance of randomness: i.e. more parents = smaller
            #chance of being completely random
            try:
                self.newTraits.append(deepcopy(self.parentList[inhChance][trait]))
                #checks if a random parent's trait is there, if out of range
                #(because parent age isn't old enough or if the random triggers!)
                #then it does a random trait.
            except IndexError as e:
                if "list index out of range" in str(e):
                    self.newTraits.append(deepcopy(randomTrait[random.randint(0,4)]))
                    #random trait is added if what we want is out of range
            else:
                self.newTraits.append(deepcopy(self.parentList[inhChance][trait]))

    def splicedGen(self):
    #i realized most of the way through making this i only need to output one kid
    #and not have a whole list and so i could just choose two parents,
    #but this works and if we ever want a list in the future instead of just one result, voila.
    
        #using numpy to make a normal distribution, so generally it's cut in
        #about half, but it can be spliced sometimes nearer to the ends
        #need to find an average:
        ageSum = 0
        for parent in self.parentList:
            ageSum += parent.age
        aveAge = ageSum/len(self.parentList)
        aveStaDev = aveAge/4
        sample = 1
        slice = np.random.normal(loc=aveAge,scale=aveStaDev,size=sample)
        #now that we have the place to slice, we need to slice and catalogue
        catalogue = []
        for i in len(self.parentList) - 1:
            catalogue.append(deepcopy([self.parentList[:slice],self.parentList[slice:]]))
            #stores each parent's slices as the value of a num in a dictionary.
        #because it's directly spliced, the magnitudes don't need to be randomized
        shiftOver = random.randint(1,len(self.parentList) - 1)
        #shifting over 0 times or the amount of parents achieves nothing
        chosen = random.randint(0,len(self.parentList) - 1)
        self.newTraits = deepcopy(catalogue[chosen][0] + 
        catalogue[(chosen+shiftOver) % len(self.parentList)][1])
        self.age = len(self.newTraits)
        #takes a random first half and adds (then mod's) a number and attach 
        #the second half, slicing together the two.


class CalculateWeight:
#preWeighted is list of the current balance of traits, we input a new series of
#traits and for each input, a random trait will be pushed out of the balance,
#otherwise as more and more generations go on, they will have less value
    def __init__(self,preWeighted,parentList):
        self.preWeighted = preWeighted
        self.parentList = parentList
        self._calculateNew()
    #don't need to access calculate except for this, so make it private
    def _calculateNew(self):
        #for each parent
        for parent in self.parentList:
            #for each "trait" in the parent
            for cmd in parent:
                if cmd == "forward":
                    self.preWeighted.append("forward")
                elif cmd == "left":
                    self.preWeighted.append("left")
                elif cmd == "right":
                    self.preWeighted.append("right")
                elif cmd == "backward":
                    self.preWeighted.append("backward")
                elif cmd == "circle":
                    self.preWeighted.append("circle")
                del self.preWeighted[random.randint(0,99)]
        return self.preWeighted