import turtle
import math
import random
import cells
import behavior

class drawTraits:
    def __init__(self,target):
        self.target = target
        self.target.turtle.goto(self.target.xCor,self.target.yCor)
        self.target.turtle.pendown()
        for trait in self.target.traitList:
            self.interpretTraits(trait)
        self.target.turtle.penup()
        self.reflections()
        
        #making a seperate list of the commands so copies can follow along
        
    def interpretTraits(self,trait):
        #translate the command into turtle movements
        if trait.magnitude == 0:
            if trait.command == "forward" or trait.command == "backward":
                trait.magnitude = random.randint(1,6) * 5
                self.executeTrait(trait)
                #forward and backwards have the same magnitude limits, so the above code
                #consolidates that, and then dispenses the proper command as well.
            elif trait.command == "left" or trait.command == "right":
                trait.magnitude = random.randint(1,18) * 15
                self.executeTrait(trait)
                #left,right, and circle have the same magnitude limits, so the code
                #consolidates that, and then dispenses the proper command as well.        
            elif trait.command == "circle":
                trait.magnitude = random.randint(1,18) * 15
                trait.cirRad = random.randint(1,30)
                self.executeTrait(trait)
            
    
    def executeTrait(self,trait):
        if trait.command == "forward" or "backward" or "circle":
            self.move(trait)
            return
        elif trait[0] == "left":
            self.target.turtle.left(trait.magnitude)
            return
        elif trait[0] == "right":
            self.target.turtle.right(trait.magnitude)
            return
    
    #making a class that incrementally moves the commands, to check if it is
    #out of bounds.
    def move(self,trait):
        counter = 0
        #because circle uses a slightly different call, it needs its own thing
        if trait.command == "circle":
            while trait.magnitude > counter:
                if self.target.insideBox(self.target.turtle):
                    self.target.turtle.pendown()
                else:
                    self.target.turtle.penup()
                self.target.turtle.circle(trait.cirRad,1)
                counter += 1
        else:
            while trait.magnitude > counter:
                if self.target.insideBox(self.target.turtle):
                    self.target.turtle.pendown()
                else:
                    self.target.turtle.penup()
                if trait.command == "forward":
                    self.target.turtle.forward(1)
                else:
                    self.target.turtle.backward(1)
                counter += 1
                
    
    #because it is written out confusingly, i made it it's own function for ease of viewing
    
    def reflections(self):
        for copy in range(self.target.copies):
            self.target.turtle.goto(self.target.xCor,self.target.yCor)
            self.target.turtle.setheading(0)
            self.target.turtle.left(360/self.target.copies * copy)
            self.target.turtle.pendown()
            
            for trait in self.target.traitList:
                self.executeTrait(trait)
            self.target.turtle.penup()

#copied this class from a previous project

    """def animate(self):
        self.target.turtle.clear()
        self.degrees += 1
        self.target.turtle.right(self.degrees)
        self.circleShape()
        self.target.turtle.setheading(0)
        self.target.draw()"""