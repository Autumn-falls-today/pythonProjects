import turtle 
import cells
import time
import drawing
import behavior
from copy import deepcopy

"""===================================================================="""
WINDOW  = None
# X and Y dimensions of the window; measured in pixels
WINX, WINY = 500, 500

def main():
    """Main function"""
    # Do not edit
    def setupWin():
        global WINDOW
        # making turtle object
        WINDOW = turtle.Screen()
        # setup the screen size
        WINDOW.setup(WINX,WINY)
        # set the background color
        WINDOW.bgcolor("white")

    
    setupWin()


    """===================================================================="""

    mouseTurt = turtle.Turtle()
    cells.turtleQOL(mouseTurt)
    #need to detect where the mouse goes^
    
    # Turn off automatic screen updates
    WINDOW.tracer(0)
    
    """===================================================================="""

    #setup
    test = cells.Grid(3,3,135)
    test.makeGrid()
    for i in range(20):
        for k in [["forward",0],["left",0],["right",0],["backward",0],["circle",0,0]]:
            behavior.newGen.weightedOdds.append(cells.Trait(k))
            #sets up weightedOdds list
    
    for cell in test.cells:
        #happens on newgen:
        behavior.newGen(cell,[])
    
    
    def middleman(event):
        mouse_x = event.x - WINX / 2
        mouse_y = WINY / 2 - event.y
        mouseTurt.goto(mouse_x,mouse_y)
        test.checkOver(mouseTurt)

    #constantly detecting/running:
    WINDOW.getcanvas().bind("<Motion>", middleman)
    def TICK():
        for cell in test.cells:
            cell.makeOutline(test.cells)
            drawing.drawTraits(cell)
            #for trait in cell.traitList:
                #print(trait.command,trait.magnitude)
        WINDOW.update()
        turtle.ontimer(TICK,200)

    TICK()
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    """===================================================================="""
    
    WINDOW.mainloop()

main()