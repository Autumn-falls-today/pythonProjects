import turtle 
import cells
import time
import drawing
import behavior
from copy import deepcopy

"""===================================================================="""
WINDOW  = None
# X and Y dimensions of the window; measured in pixels
WINX, WINY = 500, 500

def main():
    """Main function"""
    # Do not edit
    def setupWin():
        global WINDOW
        # making turtle object
        WINDOW = turtle.Screen()
        # setup the screen size
        WINDOW.setup(WINX,WINY)
        # set the background color
        WINDOW.bgcolor("white")

    
    setupWin()
    """===================================================================="""

    # Turn off automatic screen updates
    WINDOW.tracer(0)
    
    """===================================================================="""
    
    test = cells.Grid(3,3,135)
    test.makeGrid()
    
    for i in range(20):
        for k in [["forward",0],["left",0],["right",0],["backward",0],["circle",0,0]]:
            behavior.newGen.weightedOdds.append(cells.Trait(k))

    for cell in test.cells:
        behavior.newGen(cell,[])
        drawing.drawTraits(cell)
        for trait in cell.traitList:
            print(trait.command,trait.magnitude)
    

    """===================================================================="""
    
    WINDOW.mainloop()

main()