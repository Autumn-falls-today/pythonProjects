import turtle
import shapes
import math


"""=========================================================================="""
WINDOW  = None
# X and Y dimensions of the window; measured in pixels
WINX, WINY = 450, 450

def main():
    """Main function"""
    # Do not edit
    def setupWin():
        global WINDOW
        # making turtle object
        WINDOW = turtle.Screen()
        # setup the screen size
        WINDOW.setup(WINX,WINY)
        # set the background color
        WINDOW.bgcolor("white")

    setupWin()
    """=================================================================="""
    
    squareVertexList = [[10,10],[10,-10],[-10,-10],[-10,10]]
    triangleVertexList = [[10,10],[20,20],[30,10]]
    square = shapes.Shape(squareVertexList)
    triangle = shapes.Shape(triangleVertexList)
    
    print(square.checkOverlapping(triangle))
    
    """=================================================================="""
    
    WINDOW.mainloop()

main()