import turtle
import math

class Shape:
    def __init__(self,cartesianVertexList,vertVelocity = 0, horVelocity = 0,moveable = False):
        
        #relative vertex list tells you how to make a shape -- contains
        #angle/distance pairs
        self.polarVertexList = []
        for cCoords in cartesianVertexList:
            self.polarVertexList.append([(cCoords[0] ** 2 + cCoords[1] ** 2) ** .5,
            math.atan2(cCoords[1], cCoords[0])])
        
        #here we get x and y of the center
        self.centX, self.centY = averagePoints(cartesianVertexList)
        
        #vertical and horizontal velocities, obv
        self.vertVelocity = vertVelocity
        self.horVelocity = horVelocity
        
        #checks if it is a movable or "environmental" shape
        self.movable = moveable
        
        
        #spin is in units of radians per frame that the angle changes/turns
        self.spin = 0
        
        #list of lines, it's a surprise tool that will help us later
        self.lineList = []
        for i in range(len(cartesianVertexList)):
            self.lineList.append([cartesianVertexList[i-1], 
            cartesianVertexList[i]])
        
        #needed to calculate force bc F = ma :D actually forget this i don't actually,
        #however i'll keep this stuff here and commented for posterity
        #self.area = shoelace(self.lineList)
    
    def checkOverlapping(self,closeShape):
        
        #checks each line of our shape against each line of target shape
        for i in range(len(self.lineList)):
            #for each vertex in the shape close to it
            for k in range(len(closeShape.lineList)):
                
                if isColliding(self.lineList[i],closeShape.lineList[k],self,closeShape):
                    return True 
                else:
                    continue
        return False
    
    def move(self):
        #here we calculate where the CoM would be (using a temp CoM and temp
        #angles until finalized). first we need to affect gravity onto the shape
        #and then move the temp CoM where its velocity (+new gravity) takes it
        #and if no lines cross with any other lines, it is finalized. if there
        #is a collision, we then calculate all the angles and stuff
        pass
        
    def getCollisionPosition(self, closeShape):
        #checks which vertex collides first and at what time and then returns 
        #the vertices at that time as well at the ID of the collision vertex
        vertex = -1
        t = 1
        for i in len(self.polarVertexList()):
            for line in closeShape.lineList():
                t1 = doMath(self.polarVertexList[i], self, line, closeShape)
                if(t1 < t):
                    t = t1
                    vertex = i
                    #edge case when two t are equal
        return [vertex,t]
    
    def applyCollisionForces(self):
        #actually moves forces
        pass
    
    def draw(self):
        #basic stuff
        pass
    

    

def averagePoints(cVertexList):
    #this averages the points x and y coords and returns it, wanted to clean up
    #the init function as best as i could.
    xVal = 0
    yVal = 0
    for vertex in cVertexList:
        xVal += vertex[0]
        yVal += vertex[1]
    return[xVal/2,yVal/2]

def isColliding(aLine,bLine,aShape,bShape):
    #i did this code but then had to change it to reflect new names, so this
    #fixes that though it may be a little confusing inside the function
    A1 = aLine[0]
    A2 = aLine[1]
    B1 = bLine[0]
    B2 = bLine[1]
    
    #getting the mx + b formulas for the lines. 
    slopeA = (A2[1]-A1[1])/(A2[0]-A1[0])
    c = A1[1] - slopeA * A1[0]
    slopeB = (B2[1]-B1[1])/(B2[0]-B1[0])
    d = B1[1] - slopeA * B1[0]
    
    #now we check where the intercepting point of those two lines would be
    try:
        solution = (d - c)/(slopeA - slopeB)
    except ZeroDivisionError:
        #parallel lines
        return False
    else:
        solution = (d - c)/(slopeA - slopeB)
    
    #check if that point is on BOTH lines. If it's on both we say it is intersecting.
    if (min(A1[0],A2[0]) <= (slopeA * solution + c) <= (max(A1[1],A2[1]))) and (
    min(B1[0],B2[0]) <= (slopeB * solution + d) <= (max(B1[1],B2[1]))):
        return True
    else:
        return False
    
def polarToCartesian(coordSet,targetShape):
        #takes a polar coordinate and makes it cartesian
            x = targetShape.centX + math.cos(coordSet[1]) * coordSet[0]
            y = targetShape.centY + math.sin(coordSet[1]) * coordSet[0]
            return[x,y]

#def shoelace(lineList):
#    #determines the area by a math formula i don't completely get, but i get the code!
#    
#    area = 0.0
#    for i in range(len(lineList)):
#        x1, y1 = lineList[i - 1][0]
#        x2, y2 = lineList[i][1]
#        area += (x1 * y2) - (x2 * y1)
#
#    return abs(area / 2.0)