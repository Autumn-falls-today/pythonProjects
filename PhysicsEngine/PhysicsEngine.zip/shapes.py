import turtle

class Shape:
    def __init__(self,relativeVertexList,vertVelocity = 0,
    horVelocity = 0,moveable = False):
        self.centX = averagePoints(relativeVertexList)[0]
        self.centY = averagePoints(relativeVertexList)[1]
        #relative vertex list tells you how to make a shape -- contains
        #angle/move pairs of commands
        self.relativeVertexList = relativeVertexList
        #vertical and horizontal velocities, obv
        self.vertVelocity = vertVelocity
        self.horVelocity = horVelocity
        #checks if it is a movable or "environmental" shape
        self.movable = movable
        #assumes many shapes, this won'tbe able to run a ton of shapes at once 
        #(i predict), so don't do this, but we can leave it here for posterity
        """#makes a private variable for farthest point from CoM, if any points are
        #near that, it will later check if there are overlapping lines, otherwise
        #it won't waste time checking for overlapping lines.
        self.furthestPointDist = self.fPD()"""
        #makes a list that will be called later to keep track of x,y coords
        #of each vertex as above list is all relative, and this list will change
        self.vertexPosList = []
        #also need to keep track of the penultimate vertex coords for collision
        #tracking purposes
        self.lastVertexPosList = []
        """#don't know if i will get to it, but use shoelace formula to find area/mass
        #for when two movable objects collide."""
    
    
    def checkOverlapping(self,closeShape):
        #for each shape, first vertex is repeated last so -1
        for i in range(len(self.vertexPosList)-1):
            #for each vertex in the shape close to it
            for k in range(len(closeShape.vertexPosList)-1):
                #make things look simpler by moving to another function to do math
                if intersect(self.vertexPosList[i],self.vertexPosList[i+1],
                closeShape.vertexPosList[k],closeShape.vertexPosList[k+1]):
                    print("intersecting")
                else:
                    print("not intersecting.")

def averagePoints(pointXYList):
    #this averages the points x and y coords and returns it, wanted to clean up
    #the init function as best as i could.
    xVal = 0
    yVal = 0
    for i in pointXYList:
        xVal += i[0]
        yVal += i[1]
    return[xVal,yVal]

def intersect(A1,A2,B1,B2):
    slopeA = (A2[1]-A1[1])/(A2[0]-A1[0])
    c = A1[1] - slopeA * A1[0]
    slopeB = (B2[1]-B1[1])/(B2[0]-B1[0])
    d = B1[1] - slopeA * B1[0]
    #now we have mx + b formulas for the lines. we check where the intercepting
    #point of those two lines would be, and then check if that point is on BOTH
    #lines. if it's only on one it's fine, if its on both it isn't fine.
    try:
        solution = (d - c)/(slopeA - slopeB)
    except ZeroDivisionError:
        #parallel lines
        return False
    else:
        solution = (d - c)/(slopeA - slopeB)
    if (min(A1[0],A2[0]) < (slopeA * solution + c) < (max(A1[1],A2[1]))) and (
    min(B1[0],B2[0]) < (slopeB * solution + d) < (max(B1[1],B2[1]))):
        return True