import turtle
import math

class Shape:
    def __init__(self,polarVertexList,vertVelocity = 0, horVelocity = 0,moveable = False):
        self.centX = averagePoints(polarVertexList)[0]
        self.centY = averagePoints(polarVertexList)[1]
        
        #relative vertex list tells you how to make a shape -- contains
        #angle/distance pairs
        self.polarVertexList = polarVertexList
        
        #vertical and horizontal velocities, obv
        self.vertVelocity = vertVelocity
        self.horVelocity = horVelocity
        
        #checks if it is a movable or "environmental" shape
        self.movable = movable
        
        #also need to keep track of the next vertex coords for collision
        #tracking purposes
        self.potentialVertexPosList = []
        
        #need to keep track of cartesian points later
        self.cartesianCoordsList = []
        
        #spin is in units of radians per frame that the angle changes/turns
        self.spin = 0
        
        """#don't know if i will get to it, but use shoelace formula to find area/mass
        #for when two movable objects collide."""
    
    def checkOverlapping(self,closeShape):
        
        #checks each line of our shape against each line of target shape
        for i in range(len(self.polarVertexList)):
            #for each vertex in the shape close to it
            for k in range(len(closeShape.polarVertexList)):
                
                #connects the first and last points, probably a better way to do
                #this but i can't be bothered rn
                if i = len(self.polarVertexList):
                    if isColliding(self.polarVertexList[i],self.polarVertexList[0],
                    closeShape.polarVertexList[k],closeShape.polarVertexList[k+1],self,closeShape):
                        print("intersecting")
                    else:
                        print("not intersecting.")
                    return
                if k = len(closeShape.polarVertexList):
                    if isColliding(self.polarVertexList[i],self.polarVertexList[0],
                    closeShape.polarVertexList[k],closeShape.polarVertexList[0],self,closeShape):
                        print("intersecting")
                    else:
                        print("not intersecting.")
                    return
                
                #make things look simpler by moving to another function to do math
                if isColliding(self.polarVertexList[i],self.polarVertexList[i+1],
                closeShape.polarVertexList[k],closeShape.polarVertexList[k+1],self,closeShape):
                    print("intersecting")
                else:
                    print("not intersecting.")
                return
            
    def polarToCartesian(self,coordSet):
        #takes a polar coordinate and makes it cartesian
            x = self.centX + math.cos(coordSet[1]) * coordSet[0]
            y = self.centY + math.sin(coordSet[1]) * coordSet[0]
            return[x,y]
    
    def move(self):
        #here we calculate where the CoM would be (using a temp CoM and temp
        #angles until finalized). first we need to affect gravity onto the shape
        #and then move the temp CoM where its velocity (+new gravity) takes it
        #and if no lines cross with any other lines, it is finalized. if there
        #is a collision, we then calculate all the angles and stuff
        
    def getCollisionPosition(self):
        #checks which vertex collides first and at what time
        #and then returns the vertices at that time
        #as well at the ID of the collision vertex
        for i in self.
    
    def applyCollisionForces(self):
        #actually moves forces
    
    def draw(self):
        #basic stuff
    
def averagePoints(pointXYList):
    #this averages the points x and y coords and returns it, wanted to clean up
    #the init function as best as i could.
    xVal = 0
    yVal = 0
    for i in pointXYList:
        xVal += i[0]
        yVal += i[1]
    return[xVal,yVal]

def isColliding(a1,a2,b1,b2,aShape,bShape):
    #i did this code but then had to change it to reflect new names, so this
    #fixes that though it may be a little confusing inside the function
    A1 = aShape.polarToCartesian(a1)
    A2 = aShape.polarToCartesian(a2)
    B1 = bShape.polarToCartesian(b1)
    B2 = bShape.polarToCartesian(b2)
    
    
    slopeA = (A2[1]-A1[1])/(A2[0]-A1[0])
    c = A1[1] - slopeA * A1[0]
    slopeB = (B2[1]-B1[1])/(B2[0]-B1[0])
    d = B1[1] - slopeA * B1[0]
    #now we have mx + b formulas for the lines. we check where the intercepting
    #point of those two lines would be, and then check if that point is on BOTH
    #lines. if it's only on one it's fine, if its on both it isn't fine.
    try:
        solution = (d - c)/(slopeA - slopeB)
    except ZeroDivisionError:
        #parallel lines
        return False
    else:
        solution = (d - c)/(slopeA - slopeB)
    if (min(A1[0],A2[0]) <= (slopeA * solution + c) <= (max(A1[1],A2[1]))) and (
    min(B1[0],B2[0]) <= (slopeB * solution + d) <= (max(B1[1],B2[1]))):
        return True