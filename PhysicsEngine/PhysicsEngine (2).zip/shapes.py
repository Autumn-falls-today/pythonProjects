import turtle
import math

class Shape:
    def __init__(self,polarVertexList,vertVelocity = 0, horVelocity = 0,moveable = False):
        self.centX = averagePoints(polarVertexList)[0]
        self.centY = averagePoints(polarVertexList)[1]
        
        #relative vertex list tells you how to make a shape -- contains
        #angle/distance pairs
        self.polarVertexList = polarVertexList
        
        #vertical and horizontal velocities, obv
        self.vertVelocity = vertVelocity
        self.horVelocity = horVelocity
        
        #checks if it is a movable or "environmental" shape
        self.movable = movable
        
        #maybe need to keep track of cartesian points later
        #self.cartesianCoordsList = []
        
        #spin is in units of radians per frame that the angle changes/turns
        self.spin = 0
        
        #list of lines, it's a surprise tool that will help us later
        self.lineList = []
        for vertex in self.polarVertexList:
            self.lineList.append([self.polarVertexList[vertex-1], self.polarVertexList[vertex]])
        
        
        """#don't know if i will get to it, but use shoelace formula to find area/mass
        #for when two movable objects collide."""
    
    def checkOverlapping(self,closeShape):
        
        #checks each line of our shape against each line of target shape
        for i in range(len(self.polarVertexList)):
            #for each vertex in the shape close to it
            for k in range(len(closeShape.polarVertexList)):
                
                #connects the first and last points, probably a better way to do
                #this but i can't be bothered rn
                if i == len(self.polarVertexList):
                    if isColliding(self.polarVertexList[i],self.polarVertexList[0],
                    closeShape.polarVertexList[k],closeShape.polarVertexList[k+1],self,closeShape):
                        print("intersecting")
                    else:
                        print("not intersecting.")
                    return
                if k == len(closeShape.polarVertexList):
                    if isColliding(self.polarVertexList[i],self.polarVertexList[0],
                    closeShape.polarVertexList[k],closeShape.polarVertexList[0],self,closeShape):
                        print("intersecting")
                    else:
                        print("not intersecting.")
                    return
                
                #make things look simpler by moving to another function to do math
                if isColliding(self.polarVertexList[i],self.polarVertexList[i+1],
                closeShape.polarVertexList[k],closeShape.polarVertexList[k+1],self,closeShape):
                    print("intersecting")
                else:
                    print("not intersecting.")
                return
            
    
    def move(self):
        #here we calculate where the CoM would be (using a temp CoM and temp
        #angles until finalized). first we need to affect gravity onto the shape
        #and then move the temp CoM where its velocity (+new gravity) takes it
        #and if no lines cross with any other lines, it is finalized. if there
        #is a collision, we then calculate all the angles and stuff
        pass
        
    def getCollisionPosition(self, closeShape):
        #checks which vertex collides first and at what time and then returns 
        #the vertices at that time as well at the ID of the collision vertex
        vertex = -1
        t = 1
        for i in len(self.polarVertexList()):
            for line in closeShape.lineList():
                t1 = doMath(self.polarVertexList[i], self, line, closeShape)
                if(t1 < t):
                    t = t1
                    vertex = i
                    #edge case when two t are equal
        return [vertex,t]
    
    def applyCollisionForces(self):
        #actually moves forces
        pass
    
    def draw(self):
        #basic stuff
        pass
    

    

def averagePoints(pointXYList):
    #this averages the points x and y coords and returns it, wanted to clean up
    #the init function as best as i could.
    xVal = 0
    yVal = 0
    for i in pointXYList:
        xVal += i[0]
        yVal += i[1]
    return[xVal,yVal]

def isColliding(a1,a2,b1,b2,aShape,bShape):
    #i did this code but then had to change it to reflect new names, so this
    #fixes that though it may be a little confusing inside the function
    A1 = polarToCartesian(a1,aShape)
    A2 = polarToCartesian(a2,aShape)
    B1 = polarToCartesian(b1,bShape)
    B2 = polarToCartesian(b2,bShape)
    
    
    slopeA = (A2[1]-A1[1])/(A2[0]-A1[0])
    c = A1[1] - slopeA * A1[0]
    slopeB = (B2[1]-B1[1])/(B2[0]-B1[0])
    d = B1[1] - slopeA * B1[0]
    #now we have mx + b formulas for the lines. we check where the intercepting
    #point of those two lines would be, and then check if that point is on BOTH
    #lines. if it's only on one it's fine, if its on both it isn't fine.
    try:
        solution = (d - c)/(slopeA - slopeB)
    except ZeroDivisionError:
        #parallel lines
        return False
    else:
        solution = (d - c)/(slopeA - slopeB)
    if (min(A1[0],A2[0]) <= (slopeA * solution + c) <= (max(A1[1],A2[1]))) and (
    min(B1[0],B2[0]) <= (slopeB * solution + d) <= (max(B1[1],B2[1]))):
        return True
    
def polarToCartesian(coordSet,targetShape):
        #takes a polar coordinate and makes it cartesian
            x = targetShape.centX + math.cos(coordSet[1]) * coordSet[0]
            y = targetShape.centY + math.sin(coordSet[1]) * coordSet[0]
            return[x,y]
################################################################################

class doMath():

    def __init__(self,targetVertex,targetShape,targetLine,closeShape):
        #r is the radius (distance from center of mass) of the vertex
        #theta is the starting orientation of the vertex relative to CoM
        #s is the spin rate of the shape
        #vx is the horizontal velocity of the shape
        #vy is the vertical velocity of the shape
        #xinit is the x value in the current frame
        #yinit is the y value in the current frame
        
        #define vertex constants
        self.r = targetVertex[0]
        self.theta = targetVertex[1]
        self.s = targetShape.spin
        self.vx = targetShape.horVelocity
        self.vy = targetShape.vertVelocity
        self.xinit = polarToCartesian(targetVertex,targetShape)[0]
        self.yinit = polarToCartesian(targetVertex,targetShape)[1]
        
        #define intersection line constants
        self.x1 = polarToCartesian(targetLine[0],targetShape)[0]
        self.x2 = polarToCartesian(targetLine[1],targetShape)[0]
        self.y1 = polarToCartesian(targetLine[0],targetShape)[1]
        self.y2 = polarToCartesian(targetLine[1],targetShape)[1]
        
        self.m = 0
        if self.x1 == self.x2:
            self.m = 500 #approximate slope of line if vertical to avoid dividing by 0
        else:
            self.m = (self.y2 - self.y1) / (self.x2 - self.x1) # actual slope of line
        
        
        #sets this to the max time there could be, as the thing(s) referencing
        #this are super nested, so i'm putting them here
        self.minT = []
        
        print(self.findT(1, 0, 1))
    
        #eq3 = m*(x - x1) - (y - y1) #intersection line in point-slope form
       

    def findT(self, i, t1, t2):
        if i < 7:
            #gets the residual of the point at t1
            resid1 = round(self.m * (self.xWhenT(t1) - self.x1) - (self.yWhenT(t1) - self.y1), 1)
            
            #gets the residual of the point at t2
            resid2 = round(self.m * (self.xWhenT(t2) - self.x1) - (self.yWhenT(t2) - self.y1), 1)
            
            #checks if either residual is zero (intercepting)
            if resid1 == 0.0:
                i = 100
                t2 = t1
            elif resid2 == 0.0:
                i = 100
                t1 = t2
            
            #checks if the product is negative (crossing) and recursively calls the function
            elif ((resid1 * resid2) < 0.0):
                
                t3 = (t1 + t2)/2 #get new time between other times
                #increment depth counter by 1 with new t
                self.findT(i + 1, t1, t3)
                self.findT(i + 1, t3, t2)
                
        #the way code is written the last recursion gives 2 answers, so get min from that
        if i == 7:
            self.minT.append(t2)
        if len(self.minT) == 2:
            return min(self.minT)
   
    def xWhenT(self, t):
        return(self.r*math.cos(self.theta + t*self.s) + self.vx*t + self.xinit) #x coordinate depending on time
    
    def yWhenT(self, t):
        return(self.r*math.sin(self.theta + t*self.s) + self.vy*t + self.yinit) #y coordinate depending on time