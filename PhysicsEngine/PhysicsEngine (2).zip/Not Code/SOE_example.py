from scipy.optimize import fsolve
import numpy as np

def system_of_equations(variables, a, b):
    """
    Defines the system of three parametric equations.

    Args:
        variables (np.ndarray): A 1D array containing the current guesses for [x, y, z].
        a (float): The first parameter.
        b (float): The second parameter.

    Returns:
        np.ndarray: An array containing the residuals of each equation.
    """
    x, y, z = variables
    eq1 = x**2 + y**2 + z**2 - a
    eq2 = x + y - z - b
    eq3 = x * y * z - a * b
    return np.array([eq1, eq2, eq3])

# Define the parameters
param_a = 10.0
param_b = 2.0

# Provide an initial guess for [x, y, z]
initial_guess = np.array([1.0, 1.0, 1.0])

# Solve the system using fsolve
solution, info, ier, msg = fsolve(system_of_equations, initial_guess, 
                                  args=(param_a, param_b), full_output=True)

if ier == 1:
    print("Solution found:")
    print(f"x = {solution[0]:.4f}")
    print(f"y = {solution[1]:.4f}")
    print(f"z = {solution[2]:.4f}")
else:
    print("fsolve did not converge:")
    print(msg)

# Verify the solution (optional)
if ier == 1:
    residuals = system_of_equations(solution, param_a, param_b)
    print("\nResiduals at solution:")
    print(residuals)