import math


class doMath:
    def __init__(self,targetVertex,vertexShape,targetLine,lineShape):
        #define vertex constants
        self.vertexShape = vertexShape
        self.lineShape = lineShape
        self.targetVertex = targetVertex
        self.targetLine = targetLine
        
        self.findT()

    #New idea of what i want to do: check what is the smallest time that it crosses the line
    #then check if there is a smaller residual between right before it hits the line
    #or right after. take the smaller one and get the time from that.

    def findT(self):
        
        #make a list to keep track of the times
        timeList = []
        
        i = 1
        #get a lot of small times,and check if they cross the line or not
        while i < 17:
            t = i/16
            if isColliding([[self.vertexShape.centX+self.vertexShape.horVelocity*t,
            self.vertexShape.centY+self.vertexShape.vertVelocity*t],
            #above lines input where the vertexShapes' CoM would be
            #below inputs where the target/lines vertices would be
            [xWhenT(self.vertexShape,self.targetVertex,t),yWhenT(self.vertexShape,self.targetVertex,t)]],
            
            [[xWhenT(self.lineShape,self.targetLine[0],t),yWhenT(self.lineShape,self.targetLine[0],t)],
            [xWhenT(self.lineShape,self.targetLine[1],t),yWhenT(self.lineShape,self.targetLine[1],t)]]):
                timeList.append([i/16,True])
            else:
                timeList.append([i/16,False])
            i += 1
        
        #now we check what the smallest time when a collision happens is.
        
        for n in range(16):
            if timeList[n][1]:
                self.smallestTime = (timeList[n][0])
                break
            if n == 15 and timeList[n][1] == False:
                self.smallestTime = 1
        
    def __repr__(self):
        return str(self.smallestTime)
    
#use these functions to find where a point is at a given time
def xWhenT(targetShape, targetVertex, t):
    return(targetVertex[0]*math.cos(targetVertex[1] + t*targetShape.spin) + 
    targetShape.horVelocity*t + targetShape.centX)
    #x coordinate depending on time
    
def yWhenT(targetShape, targetVertex, t):
    return(targetVertex[0]*math.sin(targetVertex[1] + t*targetShape.spin) + 
    targetShape.vertVelocity*t + targetShape.centY) 
    #y coordinate depending on time
    

def polarToCartesian(coordSet,targetShapeXY):
        #takes a polar coordinate and makes it cartesian
            x = targetShapeXY[0] + (math.cos(coordSet[0]) * coordSet[1])
            y = targetShapeXY[1] + (math.sin(coordSet[0]) * coordSet[1])
            return[x,y]



def isColliding(aLine,bLine):
    #this finds out if two lines intersect
    A1 = aLine[0]
    A2 = aLine[1]
    B1 = bLine[0]
    B2 = bLine[1]
    
    #getting the mx + b formulas for the lines. 
    #if x cords are on the same line we just make it super big rise/run
    
    try:
        slopeA = (A2[1]-A1[1])/(A2[0]-A1[0])
    except ZeroDivisionError:
        slopeA = 500
    else:
        slopeA = (A2[1]-A1[1])/(A2[0]-A1[0])
    finally:
        #b = y - mx
        c = A1[1] - slopeA * A1[0]
    
    try:
        slopeB = (B2[1]-B1[1])/(B2[0]-B1[0])
    except ZeroDivisionError:
        slopeB = 500.1
    else:
        slopeB = (B2[1]-B1[1])/(B2[0]-B1[0])
    finally:
        #b = y - mx
        d = B1[1] - slopeB * B1[0]
    
    #now we check where the intercepting point of those two lines would be
    try:
        solution = (d - c)/(slopeA - slopeB)
    except ZeroDivisionError:
        #if the slopes are parallel, we check if one of the points is on the line
        return(c==d)
    else:
        solution = (d - c)/(slopeA - slopeB)
    
    #check if that point is on BOTH lines. If it's on both we say it is intersecting.
    if (min(A1[1],A2[1]) <= (slopeA * solution + c) <= (max(A1[1],A2[1]))) and (
    min(B1[1],B2[1]) <= (slopeB * solution + d) <= (max(B1[1],B2[1]))):
        return True
    else:
        return False
        
#gets the list of lines using the current CoM and polar coordinates
def getLines(target,centerCoords = None):
    tempLineList = []
    if centerCoords == None:
        centerCoords = [target.centX,target.centY]
    for i in range(len(target.polarVertexList)):
        tempLineList.append([polarToCartesian(target.polarVertexList[i-1],centerCoords), 
        polarToCartesian(target.polarVertexList[i],centerCoords)])
    return tempLineList