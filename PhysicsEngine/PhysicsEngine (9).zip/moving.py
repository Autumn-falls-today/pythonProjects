import math
import myMath

def manageCollision(firstShape,otherShape):

    if calcHypoDistance([firstShape.tempCentX,firstShape.tempCentY],
    [otherShape.centX,otherShape.centY]) > (firstShape.greatestDis + otherShape.greatestDis):
        #ok so above we check if the distance between the two CoM's is
        #larger than both their furthest distance added together, and now
        #below we check if overlapping
        firstShape.centX = firstShape.tempCentX
        firstShape.centY = firstShape.tempCentY
    else:
        #now we check if any overlapping lines, if so then find the collision time
        firstShape.lineList = myMath.getLines(firstShape,[firstShape.tempCentX,firstShape.tempCentY])
        for i in range(len(firstShape.polarVertexList)):
            firstShape.polarVertexList[i][1] += firstShape.spin
            
        if not firstShape.checkOverlapping(otherShape):
            firstShape.centX = firstShape.tempCentX
            firstShape.centY = firstShape.tempCentY
        else:
            for i in range(len(firstShape.polarVertexList)):
                firstShape.polarVertexList[i][1] -= firstShape.spin
            
            smallestTime = [1]
            for targetVertex in firstShape.polarVertexList:
                for targetLine in otherShape.lineList:
                    impactTime = myMath.doMath(targetVertex,firstShape,targetLine,otherShape)
                    #case when two points hit an object at the same time: i.e. parallel
                    if int(repr(impactTime)) == smallestTime[0]:
                        smallestTime.append([repr(impactTime),targetVertex,targetLine])
                    elif int(repr(impactTime)) < smallestTime[0]:
                        smallestTime = [repr(impactTime)]
                
                
                
#WHAT TO DO WHEN AN IMPACT HAPPENS:
#1. FirstShape marks the first time it would be close to other shape, then tells otherShape
#2. OtherShape --marks the earliest time one of it's vertices would hit-- too complicated, just marks
#3. FirstShape calculates effect it would have on firstShape and other but DOESN'T CHANGE YET
#4. OtherShape calculates effect it would have on firstShape and other but DOESN'T CHANGE YET
#5. Both shapes now move to the position they would be where contact and calculate effects


def getCollisionPosition(firstShape, closeShape):
    #checks which vertex collides first (smallest time) and at what time and then returns 
    #the vertices at that time as well at the ID of the collision vertex
    vertex = -1
    t = 1
    for i in range(len(firstShape.polarVertexList)):
        for line in closeShape.lineList:
            t1 = myMath.doMath(firstShape.polarVertexList[i], firstShape, line, closeShape)
            if int(repr(t1)) == 0:
                continue
            if int(repr(t1)) < t:
                t = int(repr(t1))
                vertex = i
                #make edge case for when two t are equal
    return [vertex,t]

def applyCollisionForces(target):
    #actually moves forces
    pass

def calcHypoDistance(point1, point2):

    x1, y1 = point1
    x2, y2 = point2
    
    distance = math.hypot(x2 - x1, y2 - y1)
    return distance