import math


class doMath:
    def __init__(self,targetVertex,targetShape,targetLine,closeShape):
        #r is the radius (distance from center of mass) of the vertex
        #theta is the starting orientation of the vertex relative to CoM
        #s is the spin rate of the shape
        #vx is the horizontal velocity of the shape
        #vy is the vertical velocity of the shape
        #xinit is the x value in the current frame
        #yinit is the y value in the current frame
        
        #define vertex constants
        self.r = targetVertex[0]
        self.theta = targetVertex[1]
        self.s = targetShape.spin
        self.vx = targetShape.horVelocity
        self.vy = targetShape.vertVelocity
        self.xinit = polarToCartesian(targetVertex,targetShape)[0]
        self.yinit = polarToCartesian(targetVertex,targetShape)[1]
        
        #define intersection line constants
        self.x1 = targetLine[0][0]
        self.x2 = targetLine[1][0]
        self.y1 = targetLine[0][1]
        self.y2 = targetLine[1][1]
        
        
        #start doing stuff w/ variable
        self.m = 0
        if self.x1 == self.x2:
            self.m = 500 #approximate slope of line if vertical to avoid dividing by 0
        else:
            self.m = (self.y2 - self.y1) / (self.x2 - self.x1) # actual slope of line
        
        
        self.minT = []
        
        self.findT(1, 0, 1)

    def __repr__(self):
        return(str(min(self.minT)))

    def findT(self, i, t1, t2):
        if i < 7:
            #gets the residual of the point at t1
            resid1 = round(self.m * (self.xWhenT(t1) - self.x1) - (self.yWhenT(t1) - self.y1), 1)
            
            #gets the residual of the point at t2
            resid2 = round(self.m * (self.xWhenT(t2) - self.x1) - (self.yWhenT(t2) - self.y1), 1)
            
            #checks if either residual is zero (intercepting)
            if resid1 == 0.0:
                i = 100
                t2 = t1
            elif resid2 == 0.0:
                i = 100
                t1 = t2
            
            #checks if the product is negative (crossing) and recursively calls the function
            elif ((resid1 * resid2) < 0.0):
                t3 = (t1 + t2)/2 #get new time between other times
                #increment depth counter by 1 with new t
                self.findT(i + 1, t1, t3)
                self.findT(i + 1, t3, t2)
            
            else:
                self.minT.append(0)
                self.findT(i + 1, 0, 1)
        
        #the way code is written the last recursion gives 2 answers, so get min from that
        if i == 7:
            self.minT.append(t2)
        if len(self.minT) == 2:
            return min(self.minT)
    
    def xWhenT(self, t):
        return(self.r*math.cos(self.theta + t*self.s) + self.vx*t + self.xinit) #x coordinate depending on time
    
    def yWhenT(self, t):
        return(self.r*math.sin(self.theta + t*self.s) + self.vy*t + self.yinit) #y coordinate depending on time
        
def polarToCartesian(coordSet,targetShape):
        #takes a polar coordinate and makes it cartesian
            x = targetShape.centX + math.cos(coordSet[1]) * coordSet[0]
            y = targetShape.centY + math.sin(coordSet[1]) * coordSet[0]
            return[x,y]