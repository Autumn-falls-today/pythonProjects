import turtle
import shapes
import math


"""=========================================================================="""
WINDOW  = None
# X and Y dimensions of the window; measured in pixels
WINX, WINY = 450, 450

def main():
    """Main function"""
    # Do not edit
    def setupWin():
        global WINDOW
        # making turtle object
        WINDOW = turtle.Screen()
        # setup the screen size
        WINDOW.setup(WINX,WINY)
        # set the background color
        WINDOW.bgcolor("white")

    setupWin()
    WINDOW.tracer(0)
    """=================================================================="""
    
    squareVertexList = [[10,10],[10,-10],[-10,-10],[-10,10]]
    triangleVertexList = [[-10,100],[0,120],[10,100]]
    square = shapes.Shape(squareVertexList,5)
    triangle = shapes.Shape(triangleVertexList,-5,0)
    
    def repeatingLoop():
        for shape in shapes.Registry.registry:
            shape.move()
        WINDOW.update()
        turtle.ontimer(repeatingLoop,100)
    
    
    
    repeatingLoop()
    """=================================================================="""
    
    WINDOW.mainloop()

main()