    
def manageCollision(firstShape,otherShape)
    if firstShape.moveable or firstShape.movedThisFrame = True:
        return
    
    if calcHypoDistance([firstShape.tempCentX,firstShape.tempCentY],
    [otherShape.centX,otherShape.centY]) > (firstShape.greatestDis + otherShape.greatestDis):
        #ok so above we check if the distance between the two CoM's is
        #larger than both their furthest distance added together, and now
        #below we check if overlapping
        firstShape.centX = firstShape.tempCentX
        firstShape.centY = firstShape.tempCentY
    else:
        #now we check if any overlapping lines, if so then find the collision time
        firstShape.lineList = myMath.getLines(firstShape,[firstShape.tempCentX,firstShape.tempCentY])
        for i in range(len(firstShape.polarVertexList)):
            firstShape.polarVertexList[i][1] += firstShape.spin
            
        if not firstShape.checkOverlapping(otherShape):
            firstShape.centX = firstShape.tempCentX
            firstShape.centY = firstShape.tempCentY
        else:
            for i in range(len(firstShape.polarVertexList)):
            firstShape.polarVertexList[i][1] += firstShape.spin
            
            smallestTime = [1]
            for targetVertex in firstShape.polarVertexList:
                for targetLine in otherShape.lineList:
                    impactTime = myMath.doMath(targetVertex,firstShape,targetLine,otherShape)
                        #case when two points hit an object at the same time: i.e. parallel
                        if repr(impactTime) = smallestTime[0]:
                            smallestTime.append([repr(impactTime),targetVertex,targetLine])
                        elif repr(impactTime) < smallestTime[0]:
                            smallestTime = [repr(impactTime)]
            if smallestTime[0] < 1:
                #don't want to infinitely recurse
                if otherShape.movedThisFrame:
                    return[]

#WHAT TO DO WHEN AN IMPACT HAPPENS:
#1. FirstShape marks the first time it would be close to other shape, then tells otherShape
#2. OtherShape marks the earliest time one of it's vertices would hit
#3. FirstShape calculates effect it would have on itfirstShape and other but DOESN'T CHANGE YET
#4. OtherShape calculates effect it would have on itfirstShape and other but DOESN'T CHANGE YET
#5. Both shapes now move to the position they would be where contact and calculate effects