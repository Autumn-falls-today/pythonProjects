import turtle
import Object

"""=========================================================================="""
WINDOW  = None
# X and Y dimensions of the window; measured in pixels
WINX, WINY = 450, 450
def main():
    """Main function"""
    # Do not edit
    def setupWin():
        global WINDOW
        # making turtle object
        WINDOW = turtle.Screen()
        # setup the screen size
        WINDOW.setup(WINX,WINY)
        # set the background color
        WINDOW.bgcolor("white")

    setupWin()
    WINDOW.tracer(0)
    """=================================================================="""
    
    #gravity
    Object.Registry.G = 0.025
    
    Earth = Object.SpaceObject([0,100],30,"green",[0,0])
    Moon = Object.SpaceObject([0,00],10,"grey",[0,0])
    Mars = Object.SpaceObject([0,-100],30,"red",[0,0])
    Blackhole = Object.SpaceObject([100,0],30,"black",[0,0],10000)
    
    
    def everyFrame():
        #have everything gravitate towards each other
        Object.doGravity()
        for shape in Object.Registry.register:
            #add velocities
            Object.addListIndices(shape.velocity,shape.delayedVelocity)
            #set a max speed
            if shape.velocity[0] > 25:
                shape.velocity[0] = 25
            if shape.velocity[1] > 25:
                shape.velocity[1] = 25
            #only moves if moveable
            if shape.movable:
                Object.addListIndices(shape.coords,shape.velocity)
            shape.draw()
            #reset the delayed velocity
            shape.delayedVelocity = [0,0]
            shape.dealWithIntercepts()
        turtle.ontimer(everyFrame,100)
    
    turtle.ontimer(everyFrame,100)
    
    
    """=================================================================="""
    
    WINDOW.mainloop()

main()