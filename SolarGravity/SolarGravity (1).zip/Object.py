import math
import turtle


def turtleQol(turt):
    turt.ht()
    turt.speed(0)
    turt.penup()

class Registry:
    register = []
    G = 0.025
    
    def addToRegister(target):
        Registry.register.append(target)
    
class SpaceObject(Registry):
    #can set the starting coords,size,mass,starting velocity,and whether it's moveable or not
    def __init__(self,coords,radius,color="white",velocity=[0,0],mass=None,movable = True):
        Registry.addToRegister(self)
        self.coords = coords
        self.radius = radius
        if mass == None:
            self.mass = (math.pi*radius)**2
        else:
            self.mass = mass
        self.velocity = velocity
        self.movable = movable
        
        self.turtle = turtle.Turtle()
        self.turtle.fillcolor(color)
        #need for collision stuff later
        self.delayedVelocity = [0,0]
    
    #figure out how much gravity an object exerts on another
    def exertGravity(self,target):
        #calculate gravitational force
        gMag = Registry.G*self.mass*target.mass/(self.findDistanceBetweenCenters(target)**2)
        #figure out angle, to calculate force into x and y velocities
        angle = pointToOtherAngle(target.coords,self.coords)
        addListIndices(target.velocity,exertForce(target,angle,gMag))
    
    def findMomentumForce(self):
        #calculate moving force(momentum)
        return math.hypot(self.velocity[0],self.velocity[1])
    
    #because we use this with both temp and actual centers, set up an arguement to determine
    def findDistanceBetweenCenters(self,otherShape):
        return(((self.coords[0]-otherShape.coords[0])**2 + (self.coords[1]-otherShape.coords[1])**2)**.5)

    #check if any shapes are intercepting, if so check when exactly to have a frame then
    #push away with a force based on velocity & mass
    def dealWithIntercepts(self):
        for otherShape in Registry.register:
            if otherShape != self:
                #if shapes are intersecting after movement, push away from each other (mass based)
                if self.radius+otherShape.radius>self.findDistanceBetweenCenters(otherShape):
                    #calculating the forces they will exert on each other
                    #calculating the angle between momentum and collision
                    thisShapeVelocityAngle=(pointToOtherAngle([0,0],self.velocity)- 
                    pointToOtherAngle(self.coords,otherShape.coords))
                    
                    #figure out the momentum exerted at that angle
                    thisShapeAngleMomentum=math.cos(thisShapeVelocityAngle)*self.findMomentumForce()
                    #now find it out for the otherShape:
                    otherShapeVelocityAngle=(pointToOtherAngle([0,0],otherShape.velocity)- 
                    pointToOtherAngle(otherShape.coords,self.coords))
                    otherShapeAngleMomentum=math.cos(otherShapeVelocityAngle)*otherShape.findMomentumForce()
                    #now we subtract them
                    totalForce = thisShapeAngleMomentum*self.mass/otherShape.mass - otherShapeAngleMomentum * otherShape.mass/self.mass
                    #use trig again to figure out the velocity they get, as well as the ratio
                    self.delayedVelocity[0] += (math.cos(pointToOtherAngle(self.coords,otherShape.coords))*
                    otherShape.mass/self.mass*-1)
                    self.delayedVelocity[1] += (math.sin(pointToOtherAngle(self.coords,otherShape.coords))*
                    otherShape.mass/self.mass*-1)
                    
                    #could do some extra stuff to make each collision only be calculated once per frame
                    #for both shapes, but i'm lazy :P

    #do i need to comment here? its pretty basic stuff
    def draw(self):
        self.turtle.clear()
        self.turtle.goto(self.coords)
        self.turtle.forward(self.radius)
        self.turtle.left(90)
        self.turtle.pendown()
        self.turtle.begin_fill()
        self.turtle.circle(self.radius)
        self.turtle.end_fill()
        self.turtle.penup()
        self.turtle.left(90)
        self.turtle.forward(self.radius)
        self.turtle.left(180)

#function to affect everything with gravity
def doGravity():
    for shape in Registry.register:
        for otherShape in Registry.register:
            if otherShape != shape:
                shape.exertGravity(otherShape)

#this function considers mass, so it's different than exertGravity
def exertForce(target,angle,magnitude):
    return[math.cos(angle) * magnitude / target.mass,math.sin(angle) * magnitude / target.mass]
    
#this function only needs to add lists of the same length/type together, so won't solve that here
def addListIndices(targetList,listToAdd):
    for i in range(len(targetList)):
        targetList[i] += listToAdd[i]

#use this to find the angle between one and another object
def pointToOtherAngle(originCoords,comparedCoords):
    return math.atan2(comparedCoords[1]-originCoords[1],comparedCoords[0]-originCoords[0])