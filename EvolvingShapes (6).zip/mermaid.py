classDiagram
direction BT
    class Grid {
        +rows
        +columns
        +cells
        +commands
        +parents
        +makeGrid()
        +checkOver()
    }

    class Trait {
        +command
        +magnitude
        +cirRad
    }

    class newGen {
        +weightedOdds
        +parentList
        +newTraits
        +varyAgeCop()
        +weightedGen()
        +inheritedGen()
        +splicedGen()
    }

    class drawTraits {
        +interpretTraits()
        +executeTrait()
        +move()
        +reflections()
    }


    class Cell {
	    +xCor
        +yCor
        +leng
        +ht
        +traitList
        +age
        +copies
        +hoverOver
        +selected
        +outline
        +turtle
        +degrees
        +makeOutline()
        +insideBox()
    }

    Grid <-- newGen : target
    Trait <-- Cell
    Cell <-- Grid : Cells
    Grid <-- drawTraits : target