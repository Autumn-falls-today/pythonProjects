import turtle 
import cells
import time
import drawing
import behavior
from copy import deepcopy

#THE BEST WAY TO READ THIS IS EITHER main,drawing,behavior,cells OR THE OTHER WAY AROUND
#^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
"""===================================================================="""
WINDOW  = None
# X and Y dimensions of the window; measured in pixels
WINX, WINY = 500, 500

def main():
    """Main function"""
    # Do not edit
    def setupWin():
        global WINDOW
        # making turtle object
        WINDOW = turtle.Screen()
        # setup the screen size
        WINDOW.setup(WINX,WINY)
        # set the background color
        WINDOW.bgcolor("white")

    
    setupWin()


    """===================================================================="""

    dingo = turtle.Turtle()
    cells.turtleQOL(dingo)
    mouseTurt = turtle.Turtle()
    cells.turtleQOL(mouseTurt)
    #need to detect where the mouse goes^
    
    # Turn off automatic screen updates
    WINDOW.tracer(0)
    
    """===================================================================="""
    #hover and click events,also used a bit of polymorphism along this chain of commands i think
    def hover(event):
        mouse_x = event.x - WINX / 2
        mouse_y = WINY / 2 - event.y
        mouseTurt.goto(mouse_x,mouse_y)
        test.checkOver("hover",mouseTurt,test.commands)
        test.checkOver("hover",mouseTurt,test.cells)
    def click(event):
        mouse_x = event.x - WINX / 2
        mouse_y = WINY / 2 - event.y
        mouseTurt.goto(mouse_x,mouse_y)
        test.checkOver("click",mouseTurt,test.commands)
        test.checkOver("click",mouseTurt,test.cells)
    

    #setup
    #fun fact: the only place that uses the name test is on this file, all other
    #files just refer an input of test, meaning its much easier to export any/all of these!
    test = cells.Grid(3,3,135)
    test.makeGrid()
    weightedOdds = []
    for i in range(20):
        for k in [["forward",0],["left",0],["right",0],["backward",0],["circle",0,0]]:
            weightedOdds.append(deepcopy(cells.Trait(k)))
    #makes and sets up weightedOdds list
    NGButton = cells.Cell(-40,-225,50,20)
    RSButton = cells.Cell(40,-225,50,20)
    #non grid-cell buttons-cells!
    #i do have to admit on some of the other files i do think the Buttons are
    #referred to by name(i.e. if ___ == "NGButton"), so the other files
    #can't be perfectly exported D:
    
    #sets up first gen,bc no parents in list it takes from the currently
    #evenly random weightedOdds list, meaning first gen is basically fully random
    for cell in test.cells:
        behavior.newGen(cell,[],weightedOdds)
    
    #YEAHHHHHHH MAIN SEQUENCE WOOOOOOOOOO
    def TICK():
        #draws the buttons
        WINDOW.resetscreen()
        for cell in test.commands:
            cell.makeOutline(test.commands)
            drawing.drawTraits(cell)
        #checks if any buttons have been pressed (selected), then does their respective stuff
        if test.commands[0].selected:
            test.commands[0].selected = False
            #turn it off to not trigger next cycle
            tempList = []
            for cell in test.cells:
                if cell.selected:
                    tempList.append(cell)
                    cell.selected = False
            test.parents = tempList
            #now we got a parent list
            behavior.calculateWeight(test.parents,weightedOdds)
            #affect the weightedOdds list with
            for cell in test.cells:
                behavior.newGen(cell,test.parents,weightedOdds)
                #now we give each cell their new traits for the generation
        if test.commands[1].selected:
            test.commands[1].selected = False
            #turn it off to not trigger next cycle
            for cell in test.cells:
                cell.selected = False
                behavior.newGen(cell,test.parents,weightedOdds)
            #we DON'T make a new parent list, using the same parent list we
            #just run the "giving everyone their traits" again with the same parentlist
        for cell in test.cells:
            cell.makeOutline(test.cells)
            drawing.drawTraits(cell)
        #VERY IMPORTANT PART, ACTUALLY DRAWS THE TRAITS/BOXES
        dingo.goto(-40,-230)
        dingo.write("Next Gen", align="center", font=("Arial", 6, "normal"))
        dingo.goto(40,-230)
        dingo.write("Reset Gen", align="center", font=("Arial", 6, "normal"))
        #writes what the buttons do on the buttons
        turtle.ontimer(TICK,100)
        #keep going to infinity and beyond :D

    #constantly detecting/running:
    WINDOW.getcanvas().bind("<Motion>", hover)
    WINDOW.getcanvas().bind("<Button-1>", click)
    
    #starts the main sequence! i can't really say function or loop here as those 
    #are both other things in this file, so main sequence/loop.function? will have to do
    TICK()
    

    """===================================================================="""
    
    WINDOW.mainloop()

main()